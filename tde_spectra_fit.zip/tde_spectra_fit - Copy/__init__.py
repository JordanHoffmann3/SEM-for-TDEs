# -*- coding: utf-8 -*-

"""Top-level package for TDE Spectra Fit."""

__author__ = """Adelle Goodwin"""
__email__ = 'adelle.goodwin@curtin.edu.au'
__version__ = '0.1.0'
