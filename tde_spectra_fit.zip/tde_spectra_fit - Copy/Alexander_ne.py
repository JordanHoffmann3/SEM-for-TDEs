import numpy as np

p = 3
Fvp = 1.14
vp = 4
eta = 1
z = 0.0206
d = 90 * 3.0857e24
R = 2.45e16
LF_m = 2
LF = 1
fA = 1.0
fV = 4/3 * (1 - 0.9**3)

LF_e = (
    525
    * Fvp
    * (d / 1e28) **2
    * (vp / 10) ** (-2)
    * eta ** (5/3)
    * (1 + z) ** (-3)
    * LF
    * fA ** (-1)
    * (R/1e17) ** (-2)
)

Ne = (
    4e54
    * Fvp ** 3
    * (d / 1e28) ** 6
    * (vp / 10) ** (-5)
    * eta ** (10 / 3)
    * (1 + z) ** (-8)
    * fA ** (-2) 
    * (R / 1e17) ** (-4)
    * (LF_m / LF_e)**(2-p)
)

V = fV * np.pi * R ** 3 / LF ** 4
ne = Ne / V

print(str(ne))