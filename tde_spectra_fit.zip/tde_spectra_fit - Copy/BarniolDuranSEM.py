""" synchrotron emission model from Barniol and Duran (2013) """
import numpy as np
from sympy import solve
from sympy import symbols

""" 
        This class calculates physical TDE system parameters from observed parameters from radio spectral observations. It uses the equations from Barniol and Duran (2013).

        Parameters:
            - vp is peak frequency in GHz
            - Fvp is peak flux density in mJy
            - p is the powerlaw index
            - dL is luminosity distance in Mpc
            - z is redshift 
            - t is time since jet was launched in days
            - eps_e is the fraction of energy stored in electrons
            - eps_B is the fraction of energy stored in the magnetic field
            - LF is the bulk Lorenz Factor
            - LF_m is the energy contained in electrons with the minimal LF. Either LF or LF_m must be defined
            - geo, str, is the assumed geometry, can be spherical or conical 
            - emitting_prop assumes that the emission emanates from a shell with a thickness of emitting_prop of the blastwave radius. 
            - va_gtr_vm set True if the synchrotron self absorption frequency, va, is above or equal to vm, the synhcrotron frequency at which the electrons emit. Else, set false. If va and vm cannot be identified in the spectrum set va_gtr_vm = False
            - va and vm only requred if va_gtr_vm = False
            - hot_protons set True includes hot proton correction factors
            - save: option to write parameters to text file 
            - name: str, name for text file, only required if save = True
        """
class BarniolDuranSEM:
        
    # constants and conversions
    mpc_to_cm = 3.0857e24
    c = 2.998e10  # cm/s
    msun = 1.989e33  # g
    me = 9.10938356e-28 #g
    mp = 1.672621e-24   #g
    e = 4.8e-10
    LF_TOL = 1e-1

    def __init__(
        self,
        vp=4.0,
        vp_err=0.0,
        Fvp=1.14,
        Fvp_err=0.0,
        p=3,
        dL=90,
        z=0.0206,
        t=246,
        eps_e=0.1,
        eps_B=None,
        fA=None,
        fV=None,
        LF=None,
        LF_m=None,
        geo='spherical',
        emitting_prop=1,
        va_gtr_vm=True,
        va=None,
        vm=None,
        hot_protons=True,
        save=False,
        name=None,
    ):      

        # Assign imported values
        self.vp = vp  # GHz
        self.vp_err = vp_err
        self.Fvp = Fvp  # mJy
        self.Fvp_err = Fvp_err
        self.d = dL * self.mpc_to_cm  # cm
        self.z = z
        self.t = t # days
        self.eps_e = eps_e
        self.eps_B = eps_B
        self.fA = fA
        self.fV = fV
        self.LF = LF
        self.LF_m = LF_m
        self.geo = geo
        self.emitting_prop = emitting_prop
        self.va_gtr_vm = va_gtr_vm
        self.va = va
        self.vm = vm
        self.hot_protons = hot_protons
        self.save = save
        self.name = name
        self.p = p

        # Calculate helper variables
        self.eps, self.eps_e, self.eps_B = self.get_eps()
        self.eta = self.get_eta()
        self.LF_m = self.get_LF_m()
        self.LF = self.get_LF()
        self.fA, self.fV = self.get_geo_fracs()
        self.xi = self.get_xi()
        self.chi_e = self.get_chi_e()

        # Calculate physical parameters
        self.Req, self.Req_err = self.get_Req()
        self.R, self.R_err = self.convert_R()
        self.Eeq, self.Eeq_err = self.get_Eeq() 
        self.E, self.E_err = self.convert_E()
        self.LF_e = self.get_LF_e()
        self.Ne = self.get_Ne()
        self.ne = self.get_ambientden()
        self.beta_ej = self.get_outflow_velocity()
        self.M_ej = self.get_outflow_mass()
        self.B = self.get_Bfield()
        self.E_e, self.E_e2 = self.get_electron_energy()
        self.E_B, self.E_B2 = self.get_mag_field_energy()

###############################################################################
    # Defining variables used to find physical parameters
###############################################################################

    def get_eps(self):

        eps_e = self.eps_e
        eps_B = self.eps_B
    
        if (eps_e != None) or (eps_B != None):
            if (eps_e == None):
                eps_e = eps_B * (11/6)
            elif (eps_B == None):
                eps_B = eps_e * (6/11)

            # Barniol Duran
            eps = (eps_B/eps_e) / (6/11)

            # Stein
            # eps = (eps_B/(1 + eps_B)) / (6/11)
        else:
            eps = 1
            eps_e = 1
            eps_B = 6/11

        return eps, eps_e, eps_B

###############################################################################

    def get_eta(self):
        if self.va_gtr_vm:
            eta = 1.0
            self.va = self.vp
        else:
            self.vm = self.vp
            eta = self.vm / self.va

        return eta

###############################################################################

    def get_LF_m(self):

        LF_m = self.LF_m
        if (LF_m == None):
            if (self.eps_e != None) and (np.abs(self.LF - 1) > self.LF_TOL):
                LF_m = (self.p-2)/(self.p-1) * self.eps_e * (self.mp/self.me) * self.LF
                
                # Barniol Duran suggests to keep gamma_m = chi_e*(LF-1) > 2
                if LF_m < 2:
                    LF_m = 2
            else:
                LF_m = 2

        return LF_m
        
###############################################################################

    def get_LF(self):
        if self.LF != None:
            LF = self.LF
        elif not self.va_gtr_vm:
            LF = (
                12
                * self.Fvp ** (1/3)
                * self.d ** (2/3)
                * self.vp ** (-17/24)
                * self.eta ** (35/72)
                * (1 + self.z) ** (-1/3)
                * self.t ** (-17/24)
                * self.fA ** (-7/24)
                * self.fV ** (-1/24)
            )
        elif self.LF_m != None:
            LF_m = self.LF_m
            if LF_m < 2:
                LF_m = 2
            
            chi_e = ((self.p - 2 / self.p - 1) * self.eps_e 
                     * (self.mp / self.me))
            LF = LF_m / chi_e + 1
        else:
            raise Exception("ERROR: Not enough input information.\n"
                            + "One of the following 3 options must be satisfied:\n"
                            + "1. LF is defined"
                            + "2. va_gtr_vm = False"
                            + "3. LF_m is defined")

        return LF

###############################################################################

    def get_geo_fracs(self):

        if self.geo == 'spherical':
            fA = 1.0
            if np.abs(self.LF - 1) > self.LF_TOL:
                fV = 1.0 * (1 - (1-self.emitting_prop) ** 3)
            else:
                fV = 4.0 / 3.0 * (1 - (1-self.emitting_prop) ** 3)
        elif self.geo == 'conical':
            fA = 0.1
            fV = 0.025 * 4.0 / 3.0 * (1 - (1-self.emitting_prop) ** 3)

        if self.fA != None:
            fA = self.fA 
        
        if self.fV != None:
            fV = self.fV

        return fA, fV

###############################################################################

    def get_xi(self):
        xi = 1 + (1 / self.eps_e)
        return xi        

###############################################################################

    def get_chi_e(self):
        
        if (self.eps_e != None) and (np.abs(self.LF - 1) > self.LF_TOL):
            chi_e = ((self.p - 2) / (self.p - 1) * self.eps_e 
                     * (self.mp / self.me))
            
            # Barniol Duran suggests to keep gamma_m = chi_e*(LF-1) > 2
            if chi_e * (self.LF - 1) < 2:
                chi_e = 2 / (self.LF - 1)
        else:
            # LF = 1 or eps_e unkown, so try to keep gamma_m = 2
            chi_e = 2

        return chi_e

###############################################################################
    # Calculations for physical parameters
###############################################################################

    def get_Req(self):

        # If va > vm and vm is not known, use Eq 27
        if self.va_gtr_vm and self.vm == None:
            prefac = (
                1e17
                * (21.8 * 525**(self.p - 1)) ** (1/(13 + 2*self.p))
                * self.chi_e ** ((2 - self.p) / (13 + 2*self.p))
            )

            Req = (
                prefac
                * self.Fvp ** ((6 + self.p) / (13 + 2*self.p))
                * (self.d / 1e28) ** (2 * (self.p+6) / (13 + 2*self.p))
                * (self.vp / 10) ** (-1)
                * (1 + self.z) ** (-(19 + 3*self.p) / (13 + 2*self.p))
                * self.fA ** (-(5 + self.p) / (13 + 2*self.p))
                * self.fV ** (-1 / (13 + 2*self.p))
                * self.LF ** ((self.p + 8) / (13 + 2*self.p))
            )
            
            # Corrections for the Newtonian limit
            if np.abs(self.LF - 1) < self.LF_TOL:
                Req = Req * 4 ** (1 / (13 + 2*self.p))
            else:
                Req = Req * (self.LF - 1) ** ((2-self.p) / (13 + 2*self.p))

            # Corrections for hot protons
            if self.hot_protons:
                Req = Req * self.xi ** (1/(13 + 2*self.p))

            Req_err = (
                Req * np.sqrt(
                    ((6 + self.p)/(13 + 2*self.p) * self.Fvp_err / self.Fvp)**2 
                    + ((-1) * self.vp_err / self.vp)**2
                )
            )
            
        else:
            # If va < vm or vm is known
            # Eq 23
            Req = (
                7.5e17
                * self.Fvp ** (2/3) 
                * (self.d / 1e28) ** (4/3)
                * (self.vp / 10) ** (-17/12)
                * self.eta ** (35/36)
                * (1 + self.z) ** (-5/3)
                * self.t ** (-5/12)
                * self.fA ** (-7/12)
                * self.fV ** (-1/12)
            )

            # Eq 21
            '''
            Req = (
                1.7e17
                * self.Fvp**(8/17)
                * (self.d / 1e28)**(16/17)
                * (self.vp / 10)**(-1)
                * self.eta**(35/51)
                * (1 + self.z)**(-25/17)
                * self.LF**(10/17)
                * self.fA**(7/17)
                * self.fV**(1/17)
            )
            '''

            # For the case that vm < va but vm is known, we use the
            # correction factors below.
            if self.va_gtr_vm:
                Req = Req * (self.vm / self.va) ** ((2 - self.p)/34)
                
            # Corrections for Newtonian limit
            if np.abs(self.LF - 1) < self.LF_TOL:
                Req = Req * 4 ** (1/17)
            
            # Corrections for hot protons
            if self.hot_protons:
                Req = Req * self.xi ** (1/12)

            Req_err = (
                Req * np.sqrt(
                    ((2/3) * self.Fvp_err / self.Fvp)**2 
                    + ((-17/12) * self.vp_err / self.vp)**2
                )
            )

        # Equation given in Alexander (2016) 
        '''          
        Req = (
            3.2e15
            * self.Fvp ** (9/19)
            * (self.d / 1e26) ** (18/19)
            * (self.vp / 10) ** (-1)
            * (1 + self.z) ** (-10/19)
            * self.fA ** (-8/19)
            * self.fV ** (-1/19)
            * 4 ** (1/19)
        )
        '''

        return Req, Req_err

###############################################################################

    def convert_R(self):
        
        if np.abs(self.LF - 1) < self.LF_TOL:
            R = self.Req * self.eps ** (1/17)
            R_err = self.Req_err * self.eps ** (1/17)
        else:
            R = self.Req * self.eps ** (1/12)
            R_err = self.Req_err * self.eps ** (1/12)

        return R, R_err

###############################################################################

    def get_Eeq(self):

        # If va > vm and vm is not known, use Eq 28
        if (self.va_gtr_vm) and ((self.vm == None) or (self.va == None)):
            prefac2 = (
                1.3e48
                * 21.8 ** (-2*(self.p + 1) / (13 + 2*self.p))
                * (525 ** (self.p - 1) * self.chi_e**(2 - self.p)) 
                    ** (11 / (13 + 2*self.p))
            )

            Eeq = (
                prefac2
                * self.Fvp ** ((14 + 3*self.p) / (13 + 2*self.p))
                * (self.d / 1e28) ** (2 * (3*self.p + 14) / (13 + 2*self.p))
                * (self.vp / 10) ** (-1)
                * (1 + self.z) ** (-(27 + 5*self.p) / (13 + 2*self.p))
                * self.fA ** (-(3*(self.p + 1)) / (13 + 2*self.p))
                * self.fV ** ((2*(self.p + 1)) / (13 + 2*self.p))
                * self.LF ** ((-5*self.p + 16) / (13 + 2*self.p))
            )
            
            # Corrections for Newtonian limit
            if np.abs(self.LF - 1) < self.LF_TOL:
                Eeq = Eeq * 4 ** (11 / (13 + 2*self.p))
            else:
                Eeq = Eeq * (self.LF - 1) ** (-11 * (self.p - 2) / (13 + 2*self.p))
            
            # Corrections for hot protons
            if self.hot_protons:
                Eeq = Eeq * self.xi ** (11/(13 + 2*self.p))
                
            Eeq_err = (
                Eeq * np.sqrt(
                    (((14 + 3*self.p) / (13 + 2*self.p)) * self.Fvp_err / self.Fvp)**2 
                    + ((-1) * self.vp_err / self.vp)**2
                )
            )

        else:
            # If va < vm or vm is known
            # Eq 26
            '''
            Eeq = (
                5.7 * 1e47
                * self.Fvp ** (2/3)
                * (self.d / 1e28) ** (4/3)
                * (self.vp / 10) ** (1/12)
                * self.eta ** (5/36)
                * (1 + self.z) ** (-5/3)
                * self.t ** (13/12)
                * self.fA ** (-1/12)
                * self.fV ** (5/12)
            )
            '''

            # Eq 25
            Eeq = (
                2.5e49
                * self.Fvp**(20/17)
                * (self.d / 1e28)**(40/17)
                * (self.vp / 10)**(-1)
                * self.eta**(15/17)
                * (1 + self.z)**(-37/17)
                * self.fV**(6/17)
                * self.fA**(-9/17)
                * self.LF**(-26/17)
            )

            # For the case that vm < va but vm is known, we use the
            # correction factors below.
            if self.va_gtr_vm:
                Eeq = Eeq * (self.vm / self.va) ** (11 * (2 - self.p) / 34)
                
            # Corrections for the Newtonian limit
            if np.abs(self.LF - 1) < self.LF_TOL:
                Eeq = Eeq * 4 ** (11/17)
            
            # Corrections for hot protons
            if self.hot_protons:
                Eeq = Eeq * self.xi ** (7/12)
                
            Eeq_err = (
                Eeq * np.sqrt(
                    ((2/3) * self.Fvp_err / self.Fvp)**2 
                    + ((1/12) * self.vp_err / self.vp)**2
                )
            )

        # Alexander 2016
        '''
        Eeq = (
            1.9e46
            * self.Fvp ** (23/19)
            * (self.d / 1e26) ** (46/19)
            * (self.vp / 10) ** (-1)
            * (1 + self.z) ** (-42/19)
            * self.fA ** (-12/19)
            * self.fV ** (8/19)
            * 4 ** (11/19)
        )
        '''

        return Eeq, Eeq_err

###############################################################################

    def convert_E(self):
        
        if np.abs(self.LF - 1) < self.LF_TOL:
            fact = (11/17)*self.eps**(-6/17) + (6/17)*self.eps**(11/17)
            E = self.Eeq * fact
            E_err = self.Eeq_err * fact
        else:
            fact = (11/17)*self.eps**(-5/12) + (6/17)*self.eps**(7/12)
            E = self.Eeq * fact
            E_err = self.Eeq_err * fact

        return E, E_err

###############################################################################

    def get_LF_e(self):
        LF_e = (
            525
            * self.Fvp
            * (self.d / 1e28) ** 2
            * (self.vp / 10) ** (-2)
            * self.eta ** (5/3)
            * (1 + self.z) ** (-3)
            * self.LF
            * self.fA ** (-1)
            * (self.R / 1e17) ** (-2)
        )
        return LF_e

###############################################################################

    def get_Bfield(self):
        B = (
            1.3e-2
            * self.Fvp ** (-2)
            * (self.d / 1e28) ** (-4)
            * (self.vp / 10) ** 5
            * self.eta ** (-10 / 3)
            * (1 + self.z) ** 7
            * self.fA ** 2 
            * (self.R / 1e17) ** 4
            * self.LF ** (-3)
        )
        return B

###############################################################################

    def get_Ne(self):
        # Barniol Duran
        
        Ne = (
            1e54
            * self.Fvp ** 3
            * (self.d / 1e28) ** 6
            * (self.vp / 10) ** (-5)
            * self.eta ** (10 / 3)
            * (1 + self.z) ** (-8)
            * self.fA ** (-2) 
            * (self.R / 1e17) ** (-4)
        )
        
        if (self.va != None) and (self.vm != None):
            Ne = Ne * (self.va/self.vm)**((self.p-2)/2)
        
        # Alexander
        Ne = Ne * (self.LF_m / self.LF_e)**(1-self.p)
        Ne = 4 * Ne

        # Stein
        '''
        Ne = (
            self.E
            * (self.me*self.c**2)**(-1)
            * (-self.p+2) / (-self.p-1) 
            * self.LF_m ** (-1)
        )

        if (self.eps_e != None) and (self.eps_B != None):
            Ne = Ne * (1 - self.eps_B)/(1 + 1/self.eps_e)
        else:
            Ne = Ne * (1+6/11) **(-1)
        '''

        return Ne

###############################################################################

    def get_ambientden(self):
        V = self.fV * np.pi * self.R ** 3 / self.LF ** 4
        ne = self.Ne / V
        return ne

###############################################################################

    def get_outflow_velocity(self):
        fac = self.R * (1 + self.z) / (self.c * self.t * 24 * 60 * 60)
        x = symbols('x')
        res = solve(x / (1 - x) - fac, x)
        beta_ej = res[0]

        return beta_ej

###############################################################################

    def get_outflow_mass(self):
        # kinetic energy: E = 0.5 m v^2
        M_ej = 2 * self.E / (self.beta_ej * self.c) ** 2
        return M_ej

###############################################################################

    def get_electron_energy(self):
        E_e = (
            4.4e50 * 4   # x4 as we assume Ne_iso = 4*Ne (really for Newtonian)
            * self.Fvp ** 4
            * (self.d / 1e28) ** 8
            * (self.vp / 10) ** (-7)
            * self.eta ** 5
            * (1 + self.z) ** (-11)
            * self.LF ** 2
            * self.fA ** (-3)
            * (self.R / 1e17) ** (-6)
        )

        if self.va_gtr_vm:
            E_e = E_e * (self.LF_m / self.LF_e) ** (2 - self.p)

        # E_e = self.Ne * self.me * self.c**2 * self.LF_e * self.LF

        E_e2 = self.E * (1 - self.eps_B)/(1 + 1/self.eps_e)

        return E_e, E_e2

###############################################################################

    def get_mag_field_energy(self):
        E_B = (
            2.1e46
            * self.Fvp ** (-4)
            * (self.d / 1e28) ** (-8)
            * (self.vp / 10) ** (10)
            * self.eta ** (-20/3)
            * (1 + self.z) ** 14
            * self.fA ** 4
            * self.fV
            * (self.R / 1e17) ** 11
            * self.LF ** (-8)
        )

        # V = self.fV * np.pi * self.R ** 3 / self.LF ** 4
        # E_B = (self.B * self.LF)**2 / (8 * np.pi) * V

        E_B2 = self.E * self.eps_B
        
        return E_B, E_B2

###############################################################################
    # Functional methods
###############################################################################

    def to_string(self):
        
        print(f'Assuming ' + self.geo + ' geometry..')
        print(f'At time t = {self.t} d')
        print('--------------------------------------------------')
        print(f'The energy is: {self.Eeq} +/- {self.Eeq_err} erg, {self.E} +/- {self.E_err} erg')
        print(f'The radius is: {self.Req} +/- {self.Req_err} cm, {self.R} +/- {self.R_err} cm')
        print('--------------------------------------------------')
        print(f'For this radius and energy, I find:')
        print(f'Electron Lorentz factor = {self.LF_e}')
        print(f'Bulk source Lorentz factor: {self.LF}')
        print(f'Outflow velocity: {self.beta_ej} c')
        print(f'Outflow mass: {self.M_ej/self.msun} msun')
        print(f'Ambient density: {self.ne} cm^-3')
        print(f'Magnetic field: {self.B} G')
        print(f'Energy stored in electrons: {self.E_e} erg, {self.E_e2} erg')
        print(f'Energy stored in magnetic field: {self.E_B} erg, {self.E_B2} erg')
        print('--------------------------------------------------')

        if self.save:
            print('Writing to text file ' + self.name + '.txt..')
            np.savetxt(
                self.name + '.txt',
                [self.t, self.Req, self.Eeq, self.beta_ej, self.M_ej, self.B, self.Ne],
                header='t (d), Req (cm), Eeq (erg), velocity (c), Mass (g), Ambient density (cm^-3), B field (G), electron density',
            )

        return None

###############################################################################