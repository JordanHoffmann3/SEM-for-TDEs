""" This module defines the likelihood and prior functions needed for the emcee fitting"""
from tde_spectra_fit import init
import numpy as np

