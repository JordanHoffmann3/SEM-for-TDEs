''' synchrotron emission model from Metzger (2012) '''
import numpy as np

class MetzgerSEM:

    # constants and conversions
    mpc_to_cm = 3.0857e24
    yr_to_sec = 365.2525 * 24 * 60 * 60
    c = 2.998e10  # cm/s
    msun = 1.989e33  # g
    me = 9.10938356e-28 #g
    mp = 1.672621e-24   #g

    def __init__(
        self,
        vp = 40, #GHz
        va = 10, #GHz
        F49 = 2, #mJy
        t = 3e5, #s
        tj = 3e5,
        m_BH = 1e7,
        L_0 = 1e48, #erg/s
        p = 2.3,
        z = 0.35,
        dL = 5.7e27,  #cm
        LF = None,
        k = 2,
        #r_cross = 3e17, #cm
        #r_max = 2, #1e18 cm
        #r_num = 50,
        E_gamma = 3e53, #erg
        eps_x = 0.5,
        eps_e = None,
        eps_B = 1e-3,
        eta = 1,
        L_pow = -5/3
    ):

        self.vp = vp
        self.va = va
        self.F49 = F49
        self.t = t
        self.tj = tj
        self.m_BH = m_BH
        self.L_0 = L_0
        self.p = p
        self.z = z
        self.dL = dL
        self.LF = LF
        self.k = k
        self.E_gamma = E_gamma
        self.eps_x = eps_x
        self.eps_e = eps_e
        self.eps_B = eps_B
        self.eta = eta
        self.L_pow = L_pow

        self.tj = self.get_tj()  # Eq 1 Giannos
        self.L48 = self.get_L48()  # Eq 13
        self.eps_e, self.eps_B = self.get_eps()  # Eq 14
        self.n18 = self.get_n18()  # Eq 15
        self.LF = self.get_LF()  # Eq 16
        self.r18 = self.get_r18() # Eq 9
        self.ncnm = self.get_ncnm()
        self.nj = self.get_nj()
        self.LF_sh = self.get_LF_sh()  # Lorentz factor of the shocked cnm
        self.LF_FS = self.get_LF_FS()  # Lorentz factor of the forward shock
        self.LF_rel = self.get_LF_rel()  # Lorentz factor of the shocked material (LF_sh) relative to the unshocked jet
        self.eps_j = self.get_eps_j()  # Fraction of accreted mass used to power jet
        self.fB = self.get_fB()  # Beaming fraction
        self.E_iso = self.get_E_iso()  # Total isotropic energy
        self.E = self.get_E()  # Total beam energy (erg)
        self.M_acc = self.get_M_acc() # Total accreted mass
        self.RS_rel_cond = self.check_RS_rel()

###############################################################################

    # Eq 1 Giannos
    def get_tj(self):

        tj = self.tj
        if self.tj == None:
            t_edd = 0.24 * (self.m_BH / 1e7) ** (2/5)  # Eddington time in years
            tj = t_edd * self.yr_to_sec

        return tj

###############################################################################

    # Eq 1
    def get_L48(self):
        
        L48 = self.L_0 / 1e48

        if self.t > self.tj:
            L48 = L48 * (self.t/self.tj)**(-5/3)

        return L48

###############################################################################

    # Eq 14
    def get_eps(self):

        eps_e = self.eps_e
        eps_B = self.eps_B

        if (eps_B != None) and (eps_e == None):
            eps_e = (
                0.12 
                * (self.eps_B/1e-2)**(-1/4) 
                * (self.vp/40)**(1/2) 
                * (self.eta)**(1/2)
            )
        elif (eps_B == None) and (eps_e != None):
            eps_B = (
                eps_e ** (-4)
                * 0.12 ** (4)
                * (self.vp/10) ** (2)
                * (self.eta) ** (2)
                * 1e-2
            )
        elif (eps_B == None) and (eps_e == None):
            raise ImportError("ERROR: Either eps_e or eps_B is required.")

        return eps_e, eps_B

###############################################################################

    # Eq 15
    def get_n18(self):

        n_18 = (
            1.5 
            * (self.eps_B/1e-2)**(-3/8) 
            * (self.vp/40)**(5/12) 
            * (self.va/10)**(5/6) 
            * self.eta**(-1/4)
        )

        return n_18

###############################################################################

    # Eq 16
    def get_LF(self):

        LF = self.LF
        if LF == None:
            LF = (
                17 
                * (self.eps_B*1e2)**(5/32) 
                * (self.vp/40)**(-1/16) 
                * (self.va/10)**(-5/8) 
                * (self.F49/2)**(-1/2) 
                * self.eta**(-1/16)
            )

        return LF

###############################################################################

    def get_r18(self):

        # r = 2 * self.LF_sh**2 * self.c * self.t / (1+z)

        if self.t < self.tj:
            r18 = (
                0.78
                * (self.t/self.tj)
                * (self.tj / 1e6)
                * self.L48 ** (1/2)
                * self.n18 ** (-1/2)
            )
        else:
            r18 = (
                2.3
                * (self.t/self.tj) ** (1/2)
                * (self.tj / 1e6)
                * self.L48 ** (1/2)
                * self.n18 ** (-1/2)
            )

        return r18

###############################################################################

    def get_ncnm(self):

        ncnm = self.n18 * (self.r18)**(-self.k)

        return ncnm

###############################################################################

    def get_nj(self):
        nj = self.L_0 / (4 * np.pi * (self.r18*1e18)**2 * self.mp * self.c**3 * self.LF**2)

        if self.t > self.tj:
            nj = nj * (self.t/self.tj)**self.L_pow
        
        return nj

###############################################################################

    # Eq 2 and 6
    def get_LF_sh(self):

        if self.t < 2*self.tj:
            LF_sh = (
                self.LF
                * (1 + 2*self.LF*(self.ncnm/self.nj)**(1/2))**(-1/2)
            )
        else:
            LF_sh = ( 
                (17 - 4*self.k)
                / (16 * np.pi) 
                * self.E_iso
                / (self.mp * self.ncnm * (self.r18*1e18)**3 * self.c**2) 
            )** (1/2)
        
        return LF_sh

###############################################################################

    # Eq 3.5
    def get_LF_FS(self):

        LF_FS = np.sqrt(2) * self.LF_sh

        return LF_FS

###############################################################################

    # Eq 4
    def get_LF_rel(self):

        LF_rel = (1/2) * (self.LF/self.LF_sh + self.LF_sh/self.LF)

        return LF_rel

###############################################################################

    def get_eps_j(self):

        eps_j = (self.LF / 10) ** (-2) * 100

        return eps_j

###############################################################################

    def get_fB(self):

        fB = self.LF ** (-2) / 2

        return fB

###############################################################################

    def get_E_iso(self):

        E_iso = self.E_gamma / self.eps_x

        return E_iso

###############################################################################

    def get_E(self):

        E = self.fB * self.E_iso

        return E

###############################################################################

    def get_M_acc(self):

        M_acc = self.E / (self.eps_j * self.c**2)

        return M_acc

###############################################################################

    # Eq 5
    def check_RS_rel(self):

        RS_rel_cond = (
            13
            * self.L48**(-1/2)
            * self.ncnm**(1/2)
            * self.r18
        )

        return RS_rel_cond

###############################################################################

    def to_string(self):

        print(f"L48 = {self.L48}")
        print(f"eps_e = {self.eps_e}")
        print(f"n18 = {self.n18}")
        print(f"LF = {self.LF}")
        print(f"r18 = {self.r18}")
        print(f"ncnm = {self.ncnm}")
        print(f"nj = {self.nj}")
        print(f"LF_sh = {self.LF_sh}")
        print(f"LF_FS = {self.LF_FS}")
        print(f"LF_rel = {self.LF_rel}")
        print(f"eps_j = {self.eps_j}")
        print(f"fB = {self.fB}")
        print(f"E_iso = {self.E_iso}")
        print(f"E = {self.E}")
        print(f"M_acc = {self.M_acc}")
        print(f"RS_rel>>1 = {self.RS_rel_cond}")

###############################################################################